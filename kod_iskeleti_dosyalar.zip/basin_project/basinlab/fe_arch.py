"""Shallow clamped arch with 2D corotational Euler-Bernoulli beam elements
(Crisfield-type). SKELETON: element kinematics implemented, tangent by
finite differences (replace with analytic tangent once tests pass).
DOFs per node: (u, w, theta). Clamped ends.

Validation required before any basin run (opus.md WP5):
  1. rigid-body rotation/translation gives zero internal force;
  2. small-deflection static response vs linear beam theory;
  3. static snap-through (limit) load vs a published shallow-arch benchmark
     (cite with DOI; do not quote values from memory);
  4. mesh refinement (n_el x2) of the barrier energy and of basin labels;
  5. a few dynamic trajectories cross-checked against openseespy.
"""
from dataclasses import dataclass

import numpy as np


@dataclass
class Arch:
    span: float = 1.0
    rise: float = 0.05           # shallow: rise/span ~ 0.03-0.1
    n_el: int = 16
    EA: float = 1.0e3
    EI: float = 1.0
    rhoA: float = 1.0
    damping_mass: float = 0.0    # Rayleigh C = a0 M + a1 K0
    damping_stiff: float = 0.0

    def __post_init__(self):
        s = np.linspace(0, self.span, self.n_el + 1)
        self.X = np.column_stack((s, self.rise*np.sin(np.pi*s/self.span)))
        self.ndof = 3*(self.n_el + 1)
        fixed = [0, 1, 2, self.ndof-3, self.ndof-2, self.ndof-1]
        self.free = np.setdiff1d(np.arange(self.ndof), fixed)
        d = self.X[1:] - self.X[:-1]
        self.L0 = np.hypot(d[:, 0], d[:, 1])
        self.beta0 = np.arctan2(d[:, 1], d[:, 0])

    # --- element -----------------------------------------------------------
    def element_force(self, e, de):
        """de = (u1,w1,t1,u2,w2,t2) global displacements of element e."""
        X1, X2 = self.X[e], self.X[e+1]
        x1 = X1 + de[0:2]
        x2 = X2 + de[3:5]
        d = x2 - x1
        Ln = np.hypot(*d)
        beta = np.arctan2(d[1], d[0])
        rot = np.arctan2(np.sin(beta - self.beta0[e]), np.cos(beta - self.beta0[e]))
        t1, t2 = de[2] - rot, de[5] - rot          # local (deformational) rotations
        L0 = self.L0[e]
        N = self.EA*(Ln - L0)/L0
        M1 = self.EI/L0*(4*t1 + 2*t2)
        M2 = self.EI/L0*(2*t1 + 4*t2)
        c, s = np.cos(beta), np.sin(beta)
        B = np.array([[-c, -s, 0, c, s, 0],
                      [-s/Ln, c/Ln, 1, s/Ln, -c/Ln, 0],
                      [-s/Ln, c/Ln, 0, s/Ln, -c/Ln, 1]])
        return B.T @ np.array([N, M1, M2])

    def internal_force(self, d_full):
        f = np.zeros(self.ndof)
        for e in range(self.n_el):
            idx = np.arange(3*e, 3*e + 6)
            f[idx] += self.element_force(e, d_full[idx])
        return f

    def lumped_mass(self):
        m = np.zeros(self.ndof)
        for e, L in enumerate(self.L0):
            for node in (e, e+1):
                m[3*node:3*node+2] += 0.5*self.rhoA*L
                m[3*node+2] += self.rhoA*L**3/78     # rotary term: CHECK/justify
        return np.diag(m[self.free])

    # --- reduced (free-DOF) interface for mdof_genalpha ---------------------
    def force_tangent(self, q):
        """q: (..., n_free). Tangent by central differences (slow; TODO analytic)."""
        q = np.atleast_2d(q)
        n = len(self.free)
        F = np.empty_like(q)
        K = np.empty(q.shape + (n,))
        for b in range(q.shape[0]):
            full = np.zeros(self.ndof); full[self.free] = q[b]
            F[b] = self.internal_force(full)[self.free]
            for j in range(n):
                e = 1e-7*max(1.0, abs(q[b, j]))
                fp = full.copy(); fp[self.free[j]] += e
                fm = full.copy(); fm[self.free[j]] -= e
                K[b, :, j] = (self.internal_force(fp) - self.internal_force(fm))[self.free]/(2*e)
        return F, K

    # TODO: static equilibria (Newton + arc-length), saddle (minimum-mode
    # search) -> barrier energy; modal basis from K0, M for IC slices;
    # classify(q, v): energy < barrier and sign of midspan displacement.
