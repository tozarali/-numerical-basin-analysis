"""Generalized-alpha for M a + C v + f(q) = 0, batched over ICs.
model.force_tangent(q) -> (f [...,n], K [...,n,n]); M, C constant (n,n).
Used for truss, Beam2Mode and the FE arch (reduce batch size for FE)."""
import numpy as np


def step(q, v, a, h, M, C, model, p, tol=1e-10, maxiter=30):
    am, af, gamma, beta = p
    c1 = 1/(beta*h*h)
    f0, _ = model.force_tangent(q)
    q1 = q + h*v + 0.5*h*h*a
    for it in range(maxiter + 1):
        a1 = c1*(q1 - q - h*v) - (0.5/beta - 1)*a
        v1 = v + h*((1-gamma)*a + gamma*a1)
        f1, K1 = model.force_tangent(q1)
        r = ((1-am)*a1 + am*a) @ M.T + ((1-af)*v1 + af*v) @ C.T + (1-af)*f1 + af*f0
        scale = max(1.0, float(np.max(np.abs(f0))))
        if np.max(np.abs(r)) <= tol*scale:
            return q1, v1, a1
        if it == maxiter:
            break
        J = (1-am)*c1*M + (1-af)*gamma*h*c1*C + (1-af)*K1
        q1 = q1 - np.linalg.solve(J, r[..., None])[..., 0]
    raise RuntimeError("mdof generalized-alpha Newton failed")


def integrate_to(q, v, end, h, M, C, model, p):
    """Exact end time via one shortened final step (as energy_loss_retest)."""
    q, v = np.asarray(q, float).copy(), np.asarray(v, float).copy()
    f, _ = model.force_tangent(q)
    a = np.linalg.solve(M, (-(v @ C.T) - f)[..., None])[..., 0]
    n = int(np.floor(end/h + 1e-12))
    for _ in range(n):
        q, v, a = step(q, v, a, h, M, C, model, p)
    rem = end - n*h
    if rem > 1e-10:
        q, v, a = step(q, v, a, rem, M, C, model, p)
    return q, v
