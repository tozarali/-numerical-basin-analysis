"""Additional, saturation-resistant basin measures (opus.md WP1-3)."""
import numpy as np

from .metrics import boundary_points, entropy


def net_basin_transfer(reference, candidate):
    """Signed area measure: fraction of resolved ICs moved -1 -> +1 minus
    +1 -> -1. Zero for symmetric errors; sign shows which basin grows."""
    reference, candidate = np.asarray(reference), np.asarray(candidate)
    valid = (reference != 0) & (candidate != 0)
    n = int(valid.sum())
    if n == 0:
        return {"net": None, "to_plus": None, "to_minus": None, "valid": 0}
    to_plus = np.mean((reference == -1) & (candidate == 1) & valid) * valid.size / n
    to_minus = np.mean((reference == 1) & (candidate == -1) & valid) * valid.size / n
    return {"net": float(to_plus - to_minus), "to_plus": float(to_plus),
            "to_minus": float(to_minus), "valid": n}


def signed_boundary_shift(reference, candidate, spacing):
    """For each reference boundary midpoint, the distance to the nearest
    candidate boundary midpoint, signed +1 if the candidate label at the
    nearer reference-side cell is +1 (the + basin grew), -1 otherwise.
    Returns the mean signed and mean absolute shift. Grid units = spacing."""
    from scipy.spatial import cKDTree
    reference, candidate = np.asarray(reference), np.asarray(candidate)
    if np.any(reference == 0) or np.any(candidate == 0):
        raise ValueError("requires fully resolved grids")
    a = boundary_points(reference, spacing)
    b = boundary_points(candidate, spacing)
    if not len(a) or not len(b):
        return {"mean_signed": None, "mean_abs": None}
    dist, _ = cKDTree(b).query(a)
    dy, dx = spacing
    # sign: sample the candidate label at the reference boundary point's cell
    rows = np.clip(np.round(a[:, 0]/dy).astype(int), 0, reference.shape[0]-1)
    cols = np.clip(np.round(a[:, 1]/dx).astype(int), 0, reference.shape[1]-1)
    changed = candidate[rows, cols] != reference[rows, cols]
    sign = np.where(changed, candidate[rows, cols], 0)  # unchanged cell -> sign 0
    return {"mean_signed": float(np.mean(sign*dist)), "mean_abs": float(dist.mean()),
            "points": int(len(a))}


def entropy_box_sweep(labels, box_sizes=(2, 4, 5, 8, 10, 20)):
    """Sb/Sbb for several box widths (only those dividing the grid)."""
    n = np.asarray(labels).shape[0]
    return {int(b): entropy(labels, b) for b in box_sizes if n % b == 0}


def uncertainty_exponent(classify_ics, ics, eps_values, seed=0):
    """Grebogi-McDonald-Ott-Yorke: f(eps) = fraction of ICs whose outcome
    changes under a random +/-eps perturbation; f ~ eps^alpha.
    classify_ics: callable (N,2) -> labels in {-1,0,1}. Expensive: each eps
    needs two classifications of all ICs (reuse the base labels)."""
    rng = np.random.default_rng(seed)
    base = classify_ics(ics)
    out = []
    for eps in eps_values:
        direction = rng.normal(size=ics.shape)
        direction /= np.linalg.norm(direction, axis=1, keepdims=True)
        pert = classify_ics(ics + eps*direction)
        ok = (base != 0) & (pert != 0)
        out.append(float(np.mean(base[ok] != pert[ok])) if ok.any() else np.nan)
    f = np.asarray(out)
    good = f > 0
    alpha = (float(np.polyfit(np.log(np.asarray(eps_values)[good]), np.log(f[good]), 1)[0])
             if good.sum() >= 3 else None)
    return {"eps": list(map(float, eps_values)), "f": out, "alpha": alpha}
